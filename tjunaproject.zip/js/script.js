$(document).ready(function() {
    $('#fullpage').fullpage();
        sectionsColor: ['#FF0FF0', '#00B4CC', '#7BAABE', 'whitesmoke', '#000'],
});