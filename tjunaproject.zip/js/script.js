$(document).ready(function(){

	$("#header").mouseenter(function(){
		$("#nav_list").fadeIn(400).show();     
          });


	$("#header").mouseleave(function(){
		$("#nav_list").fadeOut(400).hide();     
          });
      });


	
      

	
	


